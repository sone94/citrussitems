-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 27, 2020 at 09:00 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `citrus`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `name`, `email`, `text`, `approved`, `created_at`) VALUES
(22, 'pera 12345', 'pera@gmail.com', 'pera pera', 0, '2020-02-27 20:50:39'),
(21, '', 'ddd@ggg.com', '', 1, '2020-02-27 20:30:02'),
(20, 'Peter', 'oeter@oer.com', 'i like your fruits!', 0, '2020-02-27 20:26:14'),
(19, 'jenna', 'jenny@123.com', 'Hm is the price little expensive?', 0, '2020-02-27 20:25:04'),
(16, 'Mike', 'mike@mike', 'Hm i like this orange', 1, '2020-02-27 20:05:46'),
(17, 'Mike', 'mike@mike', 'Hm i like this orange', 1, '2020-02-27 20:05:53'),
(18, 'pera', 'pera@gmail.com', 'pera', 1, '2020-02-27 20:18:58');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `src` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `src`, `alt`) VALUES
(1, 'images/lemon.jpg', 'lemon'),
(2, 'images/orange.jpg', 'orange'),
(3, 'images/apple.jpg', 'apple'),
(4, 'images/bannana.jpg', 'bannana'),
(5, 'images/watermelon.jpg', 'watermeon'),
(6, 'images/carrot.jpg', 'carrot'),
(7, 'images/corn', 'yellow corn'),
(8, 'images/tomato', ''),
(9, 'images/onion', 'purple onion');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `description`, `image_id`) VALUES
(1, 'lemon', 'lemon fruit', 1),
(2, 'orange', 'orange fruit ', 2),
(3, 'apple', 'red apple', 3),
(4, 'bannana', 'yellow bannana', 4),
(5, 'watermelon', 'green watermelon', 5),
(6, 'carrot', 'orange carrot', 6),
(7, 'corn', 'yellow corn', 7),
(8, 'tomato', 'red tomato', 8),
(9, 'onion', 'purple onion', 9);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
